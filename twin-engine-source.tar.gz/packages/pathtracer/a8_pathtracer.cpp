#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <string>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif

constexpr float PI=3.14159265358979323846f;
struct V{float x,y,z;V(float a=0,float b=0,float c=0):x(a),y(b),z(c){}V operator+(V b)const{return {x+b.x,y+b.y,z+b.z};}V operator-(V b)const{return {x-b.x,y-b.y,z-b.z};}V operator*(float s)const{return {x*s,y*s,z*s};}V operator/(float s)const{return {x/s,y/s,z/s};}V&operator+=(V b){x+=b.x;y+=b.y;z+=b.z;return *this;}V&operator*=(V b){x*=b.x;y*=b.y;z*=b.z;return *this;}V&operator*=(float s){x*=s;y*=s;z*=s;return *this;}};
V operator*(float s,V a){return a*s;} V mul(V a,V b){return {a.x*b.x,a.y*b.y,a.z*b.z};} float dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;} V cross(V a,V b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};} float len2(V a){return dot(a,a);} float len(V a){return std::sqrt(len2(a));} V norm(V a){float l=len(a);return l>1e-12f?a/l:V(0,0,1);} float lum(V a){return .2126f*a.x+.7152f*a.y+.0722f*a.z;} V clampv(V a,float lo,float hi){return {std::clamp(a.x,lo,hi),std::clamp(a.y,lo,hi),std::clamp(a.z,lo,hi)};} V mixv(V a,V b,float t){return a*(1-t)+b*t;} float fract(float x){return x-std::floor(x);} float noise3(V p){float q=std::sin(dot(p,V(12.9898f,78.233f,37.719f)))*43758.5453f;return fract(q);}
uint64_t h64(uint64_t x){x^=x>>30;x*=0xbf58476d1ce4e5b9ULL;x^=x>>27;x*=0x94d049bb133111ebULL;x^=x>>31;return x;}
struct RNG{uint64_t s;RNG(uint64_t x):s(x){}float next(){s=h64(s);return float(s&0xFFFFFF)*(1.0f/16777216.0f);}};
struct Mat{V c;float metal,rough;V emit;int proc;}; struct Tri{V p0,p1,p2,n0,n1,n2;int m;}; struct Light{V c,u,v,L,n;float area;}; struct Ray{V o,d;}; struct Hit{float t=1e30f,u=0,v=0;int tri=-1;V n,p;};
struct AABB{V mn{1e30f,1e30f,1e30f},mx{-1e30f,-1e30f,-1e30f};void grow(V p){mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);}void grow(AABB b){grow(b.mn);grow(b.mx);}};
struct Node{AABB b;int l=-1,r=-1,start=0,count=0;};
std::vector<Mat> mats;std::vector<Tri> tris;std::vector<Light> lights;std::vector<int> order;std::vector<Node> nodes;
AABB tb(int i){AABB b;b.grow(tris[i].p0);b.grow(tris[i].p1);b.grow(tris[i].p2);return b;} V tc(int i){auto&t=tris[i];return (t.p0+t.p1+t.p2)/3.f;}
int build(int s,int e){int id=nodes.size();nodes.push_back({});Node &n=nodes.back();for(int i=s;i<e;i++)n.b.grow(tb(order[i]));int cnt=e-s;if(cnt<=8){n.start=s;n.count=cnt;return id;}V ext=n.b.mx-n.b.mn;int ax=ext.y>ext.x?1:0;if((ax==0?ext.x:ext.y)<ext.z)ax=2;int mid=(s+e)/2;std::nth_element(order.begin()+s,order.begin()+mid,order.begin()+e,[&](int a,int b){V A=tc(a),B=tc(b);return ax==0?A.x<B.x:ax==1?A.y<B.y:A.z<B.z;});int l=build(s,mid),r=build(mid,e);nodes[id].l=l;nodes[id].r=r;return id;}
bool boxhit(const AABB&b,const Ray&r,float tmax){float t0=1e-4f,t1=tmax;for(int a=0;a<3;a++){float o=a==0?r.o.x:a==1?r.o.y:r.o.z,d=a==0?r.d.x:a==1?r.d.y:r.d.z,mn=a==0?b.mn.x:a==1?b.mn.y:b.mn.z,mx=a==0?b.mx.x:a==1?b.mx.y:b.mx.z;float inv=1.f/(std::abs(d)<1e-12f?(d<0?-1e-12f:1e-12f):d);float A=(mn-o)*inv,B=(mx-o)*inv;if(A>B)std::swap(A,B);t0=std::max(t0,A);t1=std::min(t1,B);if(t0>t1)return false;}return true;}
bool trihit(const Tri&t,const Ray&r,float &tt,float&u,float&v){V e1=t.p1-t.p0,e2=t.p2-t.p0,p=cross(r.d,e2);float det=dot(e1,p);if(std::abs(det)<1e-8f)return false;float inv=1/det;V s=r.o-t.p0;u=dot(s,p)*inv;if(u<0||u>1)return false;V q=cross(s,e1);v=dot(r.d,q)*inv;if(v<0||u+v>1)return false;tt=dot(e2,q)*inv;return tt>1e-4f;}
bool intersect(const Ray&r,Hit&h){int stack[64],sp=0;stack[sp++]=0;while(sp){int ni=stack[--sp];auto&n=nodes[ni];if(!boxhit(n.b,r,h.t))continue;if(n.count){for(int k=0;k<n.count;k++){int id=order[n.start+k];float t,u,v;if(trihit(tris[id],r,t,u,v)&&t<h.t){h.t=t;h.u=u;h.v=v;h.tri=id;}}}else{stack[sp++]=n.l;stack[sp++]=n.r;}}if(h.tri<0)return false;auto&t=tris[h.tri];h.p=r.o+r.d*h.t;h.n=norm(t.n0*(1-h.u-h.v)+t.n1*h.u+t.n2*h.v);if(dot(h.n,r.d)>0)h.n=h.n*-1;return true;}
bool occ(const Ray&r,float maxT){Hit h;h.t=maxT;return intersect(r,h);}
V env(V d){float t=std::pow(std::clamp(.5f+.5f*d.z,0.f,1.f),.72f);return V(.30f,.32f,.35f)*(1-t)+V(.76f,.78f,.82f)*t;}
V cosineHem(V n,RNG&r){float u=r.next(),v=r.next();float rr=std::sqrt(u),ph=2*PI*v;V a=std::abs(n.z)<.999f?V(0,0,1):V(1,0,0);V x=norm(cross(a,n)),y=cross(n,x);return norm(x*(rr*std::cos(ph))+y*(rr*std::sin(ph))+n*std::sqrt(1-u));}
V reflect(V d,V n){return d-n*(2*dot(d,n));}

void surfaceProps(Mat &m,V p,V n){
    float ax=std::abs(n.x),ay=std::abs(n.y),az=std::abs(n.z);float u,v;
    if(az>=ax&&az>=ay){u=p.x;v=p.y;}else if(ax>=ay){u=p.y;v=p.z;}else{u=p.x;v=p.z;}
    float micro=noise3(p*.73f);
    if(m.proc==1){ // CFRP face weave + exposed laminate edges
        float a=.5f+.5f*std::sin((u+v)*1.48f);float b=.5f+.5f*std::sin((u-v)*1.48f);float weave=a*b+(1-a)*(1-b);
        if(az>.62f){m.c*=.86f+.20f*weave;m.rough=std::clamp(m.rough+(.5f-weave)*.025f,.16f,.29f);}
        else{float ply=.5f+.5f*std::sin(p.z*5.4f+micro*.5f);m.c=mixv(m.c,V(.10f,.11f,.12f),.10f*ply);m.rough=.29f+.025f*micro;}
    }else if(m.proc==2){ // brushed/machined metal
        float radial=std::sqrt(p.x*p.x+p.y*p.y);float brush=.5f+.5f*std::sin(radial*5.8f+u*.18f);float scratch=noise3(V(u*8,v*.8,p.z*4));
        m.c*=.94f+.08f*brush;m.rough=std::clamp(m.rough+.025f*(scratch-.5f),.12f,.30f);
    }else if(m.proc==3){ // PA-CF / PCB / connector microtexture
        float layer=.5f+.5f*std::sin(p.z*9.0f);m.c*=.97f+.05f*micro;m.rough=std::clamp(m.rough+.018f*(layer-.5f),.30f,.52f);
    }else if(m.proc==4){ // rubber and silicone wire
        m.c*=.96f+.06f*micro;m.rough=std::clamp(m.rough+.025f*(micro-.5f),.52f,.82f);
    }else if(m.proc==5){ // enameled copper
        float wind=.5f+.5f*std::sin((u+v)*3.4f);m.c*=.92f+.10f*wind;m.rough=std::clamp(m.rough+.018f*(micro-.5f),.16f,.25f);
    }else if(m.proc==6){ // battery heat-shrink wrinkles
        float wrinkle=.5f+.5f*std::sin(v*.72f+1.8f*std::sin(u*.12f));m.c*=.95f+.07f*wrinkle;m.rough=.41f+.025f*micro;
    }else if(m.proc==7){m.c*=.98f+.025f*micro;m.rough=.44f+.012f*micro;}
    else if(m.proc==8){float radial=std::sqrt(p.x*p.x+p.y*p.y);m.c*=.78f+.28f*(.5f+.5f*std::sin(radial*1.2f));m.rough=.055f+.035f*micro;}
}
V fresnelSchlick(float cosTheta,V F0){float q=std::pow(std::clamp(1-cosTheta,0.f,1.f),5.f);return F0+(V(1,1,1)-F0)*q;}
V trace(Ray ray,RNG&r,int maxB){V L(0,0,0),T(1,1,1);for(int b=0;b<maxB;b++){Hit h;if(!intersect(ray,h)){L+=mul(T,env(ray.d));break;}Mat m=mats[tris[h.tri].m];surfaceProps(m,h.p,h.n);if(lum(m.emit)>0)L+=mul(T,m.emit);V wo=ray.d*-1;
 for(size_t li=0;li<lights.size();li++){auto&l=lights[li];float su=2*r.next()-1,sv=2*r.next()-1;V lp=l.c+l.u*su+l.v*sv,to=lp-h.p;float d2=len2(to),dist=std::sqrt(d2);V wi=to/dist;float nl=std::max(dot(h.n,wi),0.f),cl=std::abs(dot(l.n,wi*-1));if(nl>0&&cl>1e-5f&&!occ({h.p+h.n*.003f,wi},dist-.006f)){V hv=norm(wi+wo);float nh=std::max(dot(h.n,hv),0.f),vh=std::max(dot(wo,hv),0.f);float expn=std::clamp(2.f/(m.rough*m.rough+1e-4f)-2.f,4.f,420.f);V F0=mixv(V(.04f,.04f,.04f),m.c,m.metal);V spec=fresnelSchlick(vh,F0)*((expn+2)/(2*PI))*std::pow(nh,expn);V diff=m.c*((1-m.metal)/PI);V brdf=diff+spec;V c=mul(T,mul(brdf,l.L))*(nl*l.area*cl/std::max(d2,1e-6f));float q=lum(c);if(q>18)c=c*(18/q);L+=c;}}
 float ps=std::clamp(.10f+.80f*m.metal,.10f,.90f);bool spec=r.next()<ps;V nd;if(spec){V refl=reflect(ray.d,h.n);V jitter=cosineHem(h.n,r);float rr=m.rough*m.rough;nd=norm(refl*(1-rr)+jitter*rr);V F0=mixv(V(.04f,.04f,.04f),m.c,m.metal);T*=F0*(1.f/ps);}else{nd=cosineHem(h.n,r);T*=m.c*((1-m.metal)/(1-ps));}ray={h.p+h.n*.003f,nd};if(b>=2){float q=std::clamp(std::max({T.x,T.y,T.z}),.08f,.95f);if(r.next()>q)break;T=T/q;}}
 float q=lum(L);if(q>24)L=L*(24/q);return L;}
bool load(const std::string&p){std::ifstream f(p,std::ios::binary);char magic[8];f.read(magic,8);if(std::string(magic,8)!="A6RAY001")return false;uint32_t nt,nm,nl;f.read((char*)&nt,4);f.read((char*)&nm,4);f.read((char*)&nl,4);mats.resize(nm);for(auto&m:mats){f.read((char*)&m.c,12);f.read((char*)&m.metal,4);f.read((char*)&m.rough,4);f.read((char*)&m.emit,12);f.read((char*)&m.proc,4);}tris.resize(nt);for(auto&t:tris){f.read((char*)&t.p0,12);f.read((char*)&t.p1,12);f.read((char*)&t.p2,12);f.read((char*)&t.n0,12);f.read((char*)&t.n1,12);f.read((char*)&t.n2,12);f.read((char*)&t.m,4);}lights.resize(nl);for(auto&l:lights){f.read((char*)&l.c,12);f.read((char*)&l.u,12);f.read((char*)&l.v,12);f.read((char*)&l.L,12);l.n=norm(cross(l.u,l.v));l.area=4*len(cross(l.u,l.v));}order.resize(tris.size());std::iota(order.begin(),order.end(),0);nodes.reserve(tris.size()*2);build(0,tris.size());return true;}
void writePFM(const std::string&p,const std::vector<V>&im,int W,int H){std::ofstream f(p,std::ios::binary);f<<"PF\n"<<W<<" "<<H<<"\n-1.0\n";for(int y=H-1;y>=0;y--)for(int x=0;x<W;x++){auto c=im[y*W+x];float rgb[3]={c.x,c.y,c.z};f.write((char*)rgb,12);}}
int main(int ac,char**av){if(ac<17){std::cerr<<"usage scene out W H spp camx camy camz tx ty tz fov bounces seed y0 y1\n";return 2;}std::string scene=av[1],out=av[2];int W=atoi(av[3]),H=atoi(av[4]),spp=atoi(av[5]);V cam(atof(av[6]),atof(av[7]),atof(av[8])),tar(atof(av[9]),atof(av[10]),atof(av[11]));float fov=atof(av[12]);int mb=atoi(av[13]);uint64_t seed=std::stoull(av[14]);int y0=atoi(av[15]),y1=atoi(av[16]);if(!load(scene)){std::cerr<<"load fail\n";return 3;}V fw=norm(tar-cam),rt=norm(cross(fw,V(0,0,1))),up=norm(cross(rt,fw));float asp=float(W)/H,tanF=std::tan(fov*PI/360);std::vector<V> img(size_t(W)*(y1-y0));int strata=std::ceil(std::sqrt(float(spp)));
#pragma omp parallel for schedule(dynamic,1)
for(int y=y0;y<y1;y++)for(int x=0;x<W;x++){V sum;uint64_t ps=h64(seed ^ (uint64_t(y)*W+x+1)*0x9e3779b97f4a7c15ULL);RNG r(ps);for(int s=0;s<spp;s++){int sx=s%strata,sy=s/strata;float jx=(sx+r.next())/strata,jy=(sy+r.next())/strata;float px=((x+jx)/W*2-1)*asp*tanF,py=(1-(y+jy)/H*2)*tanF;V d=norm(fw+rt*px+up*py);sum+=trace({cam,d},r,mb);}img[size_t(y-y0)*W+x]=sum/float(spp);}writePFM(out,img,W,y1-y0);return 0;}
